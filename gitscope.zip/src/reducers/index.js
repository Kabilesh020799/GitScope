import commitReducer from '../containers/dashboard/reducer';

export {
  commitReducer,
};
