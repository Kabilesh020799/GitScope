import CommentActivity from "./commentActivity";

export default CommentActivity;
