import CommitActivity from "./commitActivity";

export default CommitActivity;
