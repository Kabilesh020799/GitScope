import LoginBackground from "./loginBackground";

export default LoginBackground;
