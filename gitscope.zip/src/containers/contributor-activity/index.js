import ContributorActivity from "./contributorActivity";

export default ContributorActivity;
