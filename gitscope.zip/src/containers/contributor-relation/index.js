import ContributorRelation from "./contributorRelation";

export default ContributorRelation;
