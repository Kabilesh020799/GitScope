import RadarChart from "./radarChart";

export default RadarChart;
