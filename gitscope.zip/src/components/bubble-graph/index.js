import BubbleGraph from "./bubbleGraph";

export default BubbleGraph;
