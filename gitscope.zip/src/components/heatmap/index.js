import Heatmap from "./heatmap";

export default Heatmap;
