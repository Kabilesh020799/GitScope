import BarChart from "./barChart";

export default BarChart;
