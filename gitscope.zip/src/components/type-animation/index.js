import TypeAnimation from "./typeAnimation";

export default TypeAnimation;
