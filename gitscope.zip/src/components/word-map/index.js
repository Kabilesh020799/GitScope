import WordMap from "./wordMap";

export default WordMap;
